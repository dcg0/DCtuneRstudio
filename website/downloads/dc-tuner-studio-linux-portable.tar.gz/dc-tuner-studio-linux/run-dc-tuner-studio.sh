#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if [ -x "./DC-Tuner-Studio-Linux-x86_64" ]; then
  exec ./DC-Tuner-Studio-Linux-x86_64
fi
exec python3 dc_tuner_studio.py
